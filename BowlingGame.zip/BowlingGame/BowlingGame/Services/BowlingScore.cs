﻿using BowlingGame.Interface;
using System;

namespace BowlingGame.Services
{
    public class BowlingScore : IBowlingScore
    {
        private int ball;
        private int[] noOfRolls = new int[21];
        private int currentRoll = 0;

        /// <summary>
        /// This method will be used to addd throws into the frame.
        /// </summary>
        /// <param name="pins"></param>
        public void AddFrameThrows(int pins)
        {
            try
            {
                noOfRolls[currentRoll++] = pins;
            }
            catch
            {
                throw ;
            }

        }

        /// <summary>
        /// This method will be used to get frame score.
        /// </summary>
        /// <param name="frameCount"></param>
        /// <returns></returns>
        public int GetFrameScore(int frameCount)
        {
            int score = 0;
            try
            {
                ball = 0;


                for (int currentFrame = 0; currentFrame < frameCount; currentFrame++)
                {
                    if (IsFrameStrike())
                        score += 10 + gameStrikBonusBalls();
                    else if (IsFrameSpare())
                        score += 10 + spareNextBall();
                    else
                        score += frameScore();
                }
            }
            catch
            {
                throw;
            }

            return score;
        }

        /// <summary>
        /// This private method will be used to check frame is stike or not.
        /// </summary>
        /// <returns></returns>
        private Boolean IsFrameStrike()
        {
            if (noOfRolls[ball] == 10)
            {
                ball++;
                return true;
            }
            return false;
        }

        /// <summary>
        /// This private method will be used to check for strike bonus.
        /// </summary>
        /// <returns></returns>
        private int gameStrikBonusBalls()
        {
            return noOfRolls[ball] + noOfRolls[ball + 1];
        }

        /// <summary>
        /// This private method will be used to check for the frame spare.
        /// </summary>
        /// <returns></returns>
        private Boolean IsFrameSpare()
        {
            if ((noOfRolls[ball] + noOfRolls[ball + 1]) == 10)
            {
                ball += 2;
                return true;
            }
            return false;
        }

        /// <summary>
        /// This private method will be used to get next spare ball.
        /// </summary>
        /// <returns></returns>
        private int spareNextBall()
        {
            return noOfRolls[ball];
        }

        /// <summary>
        /// This private method will be used to get frame score.s
        /// </summary>
        /// <returns></returns>
        private int frameScore()
        {
            return noOfRolls[ball++] + noOfRolls[ball++];
        }
    }
}


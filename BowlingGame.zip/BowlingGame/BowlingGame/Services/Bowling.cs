﻿using BowlingGame.Helper;
using BowlingGame.Interface;
using System;

namespace BowlingGame.Services
{
    public class Bowling : IBowling
    {
        private Boolean isFirstThorwInFrame = true;
        private readonly IBowlingScore score = null;

        /// <summary>
        /// Constructor used to inject game score dependency.
        /// </summary>
        /// <param name="gameScore"></param>
        public Bowling(IBowlingScore gameScore)
        {
            score = gameScore;
        }

        /// <summary>
        /// This is method is entry point of the application which will execute bowling game applictation.
        /// </summary>
        /// <param name="totalPins"></param>
        public void ExecuteBowlingFrame(int totalPins)
        {
            try
            {
                score.AddFrameThrows(totalPins);
                int bowlingFrameCount = BowlingHelper.currentFrameCount;
                ManageCurrentFrame(totalPins);
            }
            catch (Exception ex)
            {
                Logger.LogInformation(ex.Message);
            }

        }

        /// <summary>
        /// This method is used to get current frame score.
        /// </summary>
        /// <returns></returns>
        public int GetFrameScore()
        {
            int framescore = 0;
            try
            {
                framescore = score.GetFrameScore(BowlingHelper.currentFrameCount);
            }
            catch (Exception ex)
            {
                Logger.LogInformation(ex.Message);
            }
            return framescore;
        }

        /// <summary>
        /// This private method will be used to manage current frame.
        /// </summary>
        /// <param name="pins"></param>
        private void ManageCurrentFrame(int pins)
        {
            if (isFirstThorwInFrame == true)
            {
                if (ManageFrameForStrike(pins) == false)
                    isFirstThorwInFrame = false;
            }
            else
            {
                isFirstThorwInFrame = true;
                BowlingHelper.GetCurrentFrameCount();
            }
        }

        /// <summary>
        /// This private method will be used to manage frame for bowling game strike.
        /// </summary>
        /// <param name="pins"></param>
        /// <returns></returns>
        private Boolean ManageFrameForStrike(int pins)
        {
            if (pins == 10)
            {
                BowlingHelper.GetCurrentFrameCount();
                return true;
            }
            return false;
        }
    }
}
